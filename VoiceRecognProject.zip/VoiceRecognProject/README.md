#####################################################
## Usage

```java
// Create a new VoiceRecogn instance defining the audio sample rate to be used
VoiceRecogn<String> voicerecogn = new VoiceRecogn<>(16000.0f);

VoicePrint print = voicerecogn.createVoicePrint("Elvis", new File("OldInterview.wav"));

// handle persistence the way you want, e.g.:
// myUser.setVocalPrint(print);
// userDao.saveOrUpdate(myUser);
        
// Now check if the King is back
List<MatchingProcess<String>> matches = voicerecogn.identify(new File("SomeFatGuy.wav"));
MatchingProcess<String> match = matches.get(0);

if(match.getKey().equals("Elvis")) {
	System.out.println("Elvis is back !!! " + match.getLikelihoodRatio() + "% positive about it...");
}
```

