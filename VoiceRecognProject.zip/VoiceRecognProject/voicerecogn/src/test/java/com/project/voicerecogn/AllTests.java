package com.project.voicerecogn;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

import com.project.voicerecogn.processing.DiscreteAutocorrelationAtLagJTest;
import com.project.voicerecogn.processing.LinearPredictiveCodingTest;
import com.project.voicerecogn.processing.windowing.HammingWindowFunctionTest;
import com.project.voicerecogn.processing.windowing.HannWindowFunctionTest;
import com.project.voicerecogn.distances.ChebyshevDistanceCalculatorTest;
import com.project.voicerecogn.distances.EuclideanDistanceCalculatorTest;
import com.project.voicerecogn.enhancements.NormalizerTest;
import com.project.voicerecogn.features.LpcFeaturesExtractorTest;
import com.project.voicerecogn.vad.AutocorrellatedProcessingTest;

@RunWith(Suite.class)
@SuiteClasses({ 
    HammingWindowFunctionTest.class,
    HannWindowFunctionTest.class,
    DiscreteAutocorrelationAtLagJTest.class,
    LinearPredictiveCodingTest.class,
    ChebyshevDistanceCalculatorTest.class,
    EuclideanDistanceCalculatorTest.class,
    NormalizerTest.class,
    LpcFeaturesExtractorTest.class,
    AutocorrellatedProcessingTest.class,
    VoiceRecognTest.class, 
    VoicePrintConcurrencyTest.class, 
    VoicePrintTest.class
})

public class AllTests {}
