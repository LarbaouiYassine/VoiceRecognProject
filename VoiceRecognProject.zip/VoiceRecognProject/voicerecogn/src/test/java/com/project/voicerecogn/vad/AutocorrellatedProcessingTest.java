/*
 * (C) Copyright 2016 Yassine Larbaoui
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */
package com.project.voicerecogn.vad;

import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.sameInstance;
import static org.junit.Assert.assertThat;

import java.util.Arrays;
import java.util.Random;

import org.junit.Before;
import org.junit.Test;

public class AutocorrellatedProcessingTest {
    
    private static final int DEFAULT_SAMPLE_RATE = 22050;

    private AutocorrellatedProcessing vad;
    
    @Before
    public void setUp() {
        vad = new AutocorrellatedProcessing();
    }
    
    @Test
    public void vadReturnsEmptyArrayWhenFedWithPureSilence() {
        double[] output = vad.removeSilence(new double[8192], DEFAULT_SAMPLE_RATE);
        
        assertThat(output.length, is(equalTo(0)));
    }
    
    @Test
    public void vadReturnsOriginalAudioBufferWhenThereIsNoDetectableSilence() {
        double[] voiceSample = new double[8192];
        Arrays.fill(voiceSample, 1.0);
        
        double[] output = vad.removeSilence(voiceSample, DEFAULT_SAMPLE_RATE);

        assertThat(output, is(sameInstance(voiceSample)));
    }

    @Test
    public void vadReturnsOriginalAudioBufferWhenVoiceSampleIsTooSmall() {
        int vaLength = vad.getMinimumVoiceActivityLength(DEFAULT_SAMPLE_RATE);
        double[] voiceSample = new double[vaLength - 1];
        Arrays.fill(voiceSample, 1.0);
        
        double[] output = vad.removeSilence(voiceSample, DEFAULT_SAMPLE_RATE);

        assertThat(output, is(sameInstance(voiceSample)));
    }
    
    @Test
    public void vadRemovesRandomNoiseAndLeavesTheRest() {
        // for predictability, have to take min activity length into account
        // and autocorrelation buffer length -> unusual sample rate makes it easier
        int sampleRate = 40000; 
        int vaLength = vad.getMinimumVoiceActivityLength(sampleRate);
        double[] noisy = new double[8160];

        Arrays.fill(noisy, 0, vaLength, 1.0);
        makeSomeNoise(noisy, sampleRate, vaLength, noisy.length);
        
        double[] output = vad.removeSilence(noisy, sampleRate);

        assertThat(output.length, is(equalTo(vaLength)));
    }
    
    private void makeSomeNoise(double[] noisy, int sampleRate, int start, int end) {
        Random random = new Random();
        int whiteningFactor = 5000;
        for(int i = start; i < end; i++) {
            
            for(int j = 0; j < whiteningFactor; j++) {
                
                noisy[i] += (2 * random.nextDouble() - 1) * 0.3; 
            }
        }
        for(int i = start; i < end; i++) {
            noisy[i] /= whiteningFactor;
        }
    }
}
